//
// Implement the List class
//

#include <stdio.h>
#include "List.h"

//
// Inserts a new element with value "val" in
// ascending order.
//
void
List::insertSorted( int val )
{
  // Complete procedure 
}

//
// Inserts a new element with value "val" at
// the end of the list.
//
void
List::append( int val )
{
  // Complete procedure 
}

//
// Inserts a new element with value "val" at
// the beginning of the list.
//
void
List::prepend( int val )
{
  // Complete procedure 
}

// Removes an element with value "val" from List
// Returns 0 if succeeds or -1 if it fails
int 
List:: remove( int val )
{
  // Complete procedure
  return 0;
}

// Prints The elements in the list. 
void
List::print()
{
  // Complete procedure 
}

//
// Returns 0 if "value" is in the list or -1 otherwise.
//
int
List::lookup(int val)
{
  // Complete procedure 
  return 0;
}

//
// List constructor
//
List::List()
{
  // Complete procedure 
}

//
// List destructor: delete all list elements, if any.
//
List::~List()
{
  // Complete procedure 
}

