#include <sys/types.h>

/*
 * Implement the following string procedures.
 *
 * Type "man strstr" to find what each of the functions should do.
 *
 * For example, mystrcpy should do the same as strcpy.
 *
 * IMPORTANT: DO NOT use predefined string functions.
 */

char *mystrcpy(char * s1, const char * s2)
{
  /* Complete procedure */
}

size_t mystrlen(const char *s)
{
  /* Complete procedure */
}

char *mystrdup(const char *s1)
{
  /* Complete procedure */
}

char *mystrcat(char * s1, const char * s2)
{
  /* Complete procedure */
}

char *mystrstr(char * s1, const char * s2)
{
  /* Complete procedure */
}

int mystrcmp(const char *s1, const char *s2) {
  /* Complete procedure */
}

