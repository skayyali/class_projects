#include <iostream>
#include <stdlib.h>
#include "key.h"
#include "brute.h"

using namespace std;


int main(int argc, char *argv[]){
   
   if (argc != 2) exit(EXIT_FAILURE);
   
   // Create a Key from the input password
   Brute bruteKey((char*) argv[1]);
   
   //initialize the table
   bruteKey.initializeTable();
   
   //Add code here

}

Brute::Brute(char s[]){
 
   char buffer[C+1];
   
   //initialze to encrypted key
   encrypted.keySetString(s);
   
}

void Brute::initializeTable(){
   
   char buffer[C+1];   

   // Read in table T
   for (int i = 0; i < N; i++) {
      cin.getline(buffer,C+1,'\n');
      buffer[C]=0;
      T[i].keySetString(buffer);
   }
}

Key Brute::decrypt(Key brute){
   
}

